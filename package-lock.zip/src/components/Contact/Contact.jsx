import React from 'react'

const Contact = () => {
  return (
    <div className="vh-100 vw-100">
    <h1>Contact</h1>
  </div>
  )
}

export default Contact