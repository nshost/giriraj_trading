import React from 'react'

const Service = () => {
  return (
    <div className="vh-100 vw-100">
    <h1>Services</h1>
  </div>
  )
}

export default Service