import React from "react";

const About = () => {
  return (
    <>
      <div className="vh-100 vw-100">
        <h1>About</h1>
      </div>
    </>
  );
};

export default About;
